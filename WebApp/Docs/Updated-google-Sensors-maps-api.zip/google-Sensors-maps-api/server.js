require("dotenv").config();
const express = require("express");
const path = require("path");
const app = express();

// Serve static files (your HTML, CSS, JS)
app.use(express.static(__dirname));

// API endpoint to get the Maps key
app.get("/api/maps-key", (req, res) => {
  res.json({ key: process.env.GOOGLE_MAPS_API_KEY });
});

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
