async function init() {
  await customElements.whenDefined("gmp-map");

  const map = document.querySelector("gmp-map");
  const placePicker = document.querySelector("gmpx-place-picker");
  const infowindow = new google.maps.InfoWindow();

  map.innerMap.setOptions({ mapTypeControl: false });

  // Tshwane University of Technology (TUT) location
  const TUT_LOCATION = { lat: -25.732285, lng: 28.161897 };

  // Directions service and renderer
  const directionsService = new google.maps.DirectionsService();
  const directionsRenderer = new google.maps.DirectionsRenderer({
    map: map.innerMap,
  });

  // Define markers with details
  const markerData = [
    {
      position: { lat: -25.7579, lng: 28.2293 },
      title: "Sensor 1",
      info: "Temperature: 22°C<br>Humidity: 65%<br>Status: ⚠️ EMERGENCY ACTIVE",
    },
    {
      position: { lat: -25.74, lng: 28.1 },
      title: "Sensor 2",
      info: "Temperature: 24°C<br>Humidity: 60%<br>Status: ⚠️ EMERGENCY ACTIVE",
    },
    {
      position: { lat: -25.778, lng: 28.3 },
      title: "Sensor 3",
      info: "Temperature: 21°C<br>Humidity: 70%<br>Status: Active",
    },
    {
      position: { lat: -25.7, lng: 28.225 },
      title: "Sensor 4",
      info: "Temperature: 23°C<br>Humidity: 62%<br>Status: Inactive",
    },
    {
      position: { lat: -25.8, lng: 28.232 },
      title: "Sensor 5",
      info: "Temperature: 25°C<br>Humidity: 58%<br>Status: Active",
    },
  ];

  // Function to keep markers bouncing
  function keepMarkerBouncing(marker) {
    const ensureBounce = () => {
      if (marker.getAnimation() !== google.maps.Animation.BOUNCE) {
        marker.setAnimation(google.maps.Animation.BOUNCE);
      }
    };
    ensureBounce();
    setInterval(ensureBounce, 5000);
  }

  // Create markers with details
  const markers = markerData.map((data, index) => {
    const isEmergency = index < 2;
    const marker = new google.maps.Marker({
      position: data.position,
      map: map.innerMap,
      draggable: !isEmergency,
      title: data.title,
      animation: isEmergency ? google.maps.Animation.BOUNCE : null,
    });

    // Keep emergency markers bouncing forever
    if (isEmergency) {
      keepMarkerBouncing(marker);

      // Clicking a bouncing marker shows info and directions from TUT
      marker.addListener("click", () => {
        infowindow.setContent(
          `<strong>${data.title}</strong><br>${data.info}<br><em>Routing from TUT...</em>`
        );
        infowindow.open(map.innerMap, marker);

        directionsService.route(
          {
            origin: TUT_LOCATION,
            destination: marker.getPosition(),
            travelMode: google.maps.TravelMode.DRIVING,
          },
          (response, status) => {
            if (status === "OK" || status === google.maps.DirectionsStatus.OK) {
              directionsRenderer.setDirections(response);
            } else {
              infowindow.setContent(
                `${data.title}<br>Route unavailable (${status})`
              );
            }
          }
        );
      });
    } else {
      // Regular markers just show info
      marker.addListener("click", () => {
        infowindow.setContent(`<strong>${data.title}</strong><br>${data.info}`);
        infowindow.open(map.innerMap, marker);
      });
    }

    return marker;
  });

  // Place Picker logic
  placePicker.addEventListener("gmpx-placechange", () => {
    const place = placePicker.value;

    if (!place.location) {
      window.alert("No details available for input: '" + place.name + "'");
      infowindow.close();
      return;
    }

    if (place.viewport) {
      map.innerMap.fitBounds(place.viewport);
    } else {
      map.center = place.location;
      map.zoom = 17;
    }

    // Move the first (emergency) marker to the new location
    markers[0].setPosition(place.location);
    keepMarkerBouncing(markers[0]);

    infowindow.setContent(
      `<strong>${place.displayName}</strong><br>${place.formattedAddress}`
    );
    infowindow.open(map.innerMap, markers[0]);
  });
}

document.addEventListener("DOMContentLoaded", init);
